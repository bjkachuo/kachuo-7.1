<template>
  <div>
    <AMap></AMap>
  </div>
</template>

<script>

import AMap from "@/components/common/AMap"

  export default {
    name:'',
    props:[''],
    data () {
      return {

      };
    },

    components: {
      AMap
    },

    computed: {},

    beforeMount() {},

    mounted() {},

    methods: {},

    watch: {}

  }

</script>
<style lang='' scoped>

</style>