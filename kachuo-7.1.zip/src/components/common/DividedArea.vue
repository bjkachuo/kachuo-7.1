<template>
  <div class="divider-area-wrap"></div>
</template>

<script>

  export default {
    name:'',
    props:[''],
    data () {
      return {

      };
    },


  }

</script>
<style lang='css' scoped>
.divider-area-wrap{
  width: 100%;
  height: 10px;
  background: #f5f5f5;
  position: relative;
  z-index: 99;
}
</style>
